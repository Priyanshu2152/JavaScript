/*Name - Priyanshu
Student Id - 200437892
Q 2b
*/


#include<iostream>
#include<string>

using namespace std;

class Priyanshu
{
public:
  string owner;
  int houseNumber;
  double streetNumber;

  Priyanshu()
  {
    owner = " ";
    houseNumber = 0;
    streetNumber = 0;
  }

  Priyanshu(string owner, int houseNumber, double streetNumber)
  {
    this->owner = owner;
    this->houseNumber = houseNumber;
    this->streetNumber = streetNumber;
  }
};


void swap(int& x, int& y)
{
  int temp = x;
  x = y;
  y = temp;
}

int partition(Priyanshu array[], int low, int high)
{
  string pivot = array[high].owner;
  int pivotIndex = low;

  for (int i = low; i < high; i++)
  {
    if (array[i].owner <= pivot)
    {
      swap(array[pivotIndex], array[i]);
      pivotIndex++;
    }
  }
  swap(array[pivotIndex], array[high]);
  return pivotIndex;
}

void quickSort(Priyanshu array[], int low, int high)
{
  if (low < high)
  {
    int pivotIndex = partition(array, low, high);
    quickSort(array, low, pivotIndex - 1);
    quickSort(array, pivotIndex + 1, high);

  }

}

void printArray(Priyanshu array[], int arraySize)
{
  for (int i = 0; i < arraySize; i++)
  {
    cout << array[i].owner << "," << array[i].houseNumber << "," << array[i].streetNumber << endl;
  }
  cout << endl;
}

int binarySearch(Priyanshu array [], int arraySize, Priyanshu target)
{

    int low = 0;
    int high = arraySize - 1;

    while (low <= high)
    {
        int mid = (low + high)/2;
        if(target.owner == array[mid].owner)
        {
            return mid;
        }
        else if (target.owner < array[mid].owner)
        {
            high = mid - 1;
        }

        else if (target.owner > array[mid].owner)
        {
            low = mid + 1;
        }

    }

    return -low-1;
}

void printAppropriateStatement(Priyanshu array[], int arraySize, string owner, int houseNumber, double streetNumber )
{
    Priyanshu priyanshu(owner, houseNumber, streetNumber);
    if(binarySearch(array, arraySize, priyanshu) >= 0)
    {
        cout<<"The element ("<<priyanshu.owner<<", "<<priyanshu.houseNumber<<", "<<priyanshu.streetNumber<<") is found."<<endl;
    }
    else
    {
        cout<<"The element ("<<priyanshu.owner<<", "<<priyanshu.houseNumber<<", "<<priyanshu.streetNumber<<") should be at index "<<-1*(binarySearch(array, arraySize, priyanshu)+1)<<"."<<endl;
    }

}

int main()
{

  Priyanshu priyanshu1 = {"John", 3, 200.43};
  Priyanshu priyanshu2 = {"Daryl", 25, 78.92};
  Priyanshu priyanshu3 = {"Bob", 14, 1.2};
  Priyanshu priyanshu4 = {"Caren", 37, 3.4};
  Priyanshu priyanshu5 = {"Abdul", 15, 5.6};

  Priyanshu A[] = {priyanshu1, priyanshu2, priyanshu3, priyanshu4, priyanshu5} ;

  int n = sizeof(A) / sizeof(A[0]);

  cout << "The unsorted array is: " << endl;
  printArray(A, n);

  quickSort(A, 0, n - 1);


  cout << "The sorted array is: " << endl;
  printArray(A, n);
  printAppropriateStatement(A, n, "Daryl", 25, 78.92);
  printAppropriateStatement(A, n, "Kaur", 18, 9.1);


  return 0;
}
